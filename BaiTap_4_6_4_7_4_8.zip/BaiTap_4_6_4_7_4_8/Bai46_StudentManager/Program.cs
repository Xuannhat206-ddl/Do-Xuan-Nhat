using System.ComponentModel;
using System.Globalization;
using System.Text;

namespace Bai46_StudentManager;

internal static class Program
{
    [STAThread]
    static void Main() { ApplicationConfiguration.Initialize(); Application.Run(new FormStudent()); }
}

public class Student
{
    public string StudentId { get; set; } = "";
    public string FullName { get; set; } = "";
    public int Age { get; set; }
    public string Gender { get; set; } = "Nam";
    public string AvatarPath { get; set; } = "";
}

public class FormStudent : Form
{
    private readonly BindingList<Student> _students = new();
    private readonly BindingSource _source = new();
    private readonly DataGridView _grid = new();
    private readonly TextBox _txtId = new(), _txtName = new(), _txtAge = new();
    private readonly ComboBox _cboGender = new();
    private readonly PictureBox _pic = new();
    private readonly Label _lblAvatar = new();

    public FormStudent()
    {
        Text = "Bài 4.6 - Quản lý sinh viên (BindingSource & CSV)"; Width = 1050; Height = 650; StartPosition = FormStartPosition.CenterScreen;
        BuildUi();
        _source.DataSource = _students;
        _grid.DataSource = _source;
        _txtId.DataBindings.Add("Text", _source, nameof(Student.StudentId), true, DataSourceUpdateMode.OnPropertyChanged);
        _txtName.DataBindings.Add("Text", _source, nameof(Student.FullName), true, DataSourceUpdateMode.OnPropertyChanged);
        _txtAge.DataBindings.Add("Text", _source, nameof(Student.Age), true, DataSourceUpdateMode.OnPropertyChanged, 0);
        _cboGender.DataBindings.Add("SelectedItem", _source, nameof(Student.Gender), true, DataSourceUpdateMode.OnPropertyChanged);
        _source.CurrentChanged += (_, _) => LoadAvatar();
        AddStudent("SV001", "Nguyễn Văn An", 20, "Nam");
        AddStudent("SV002", "Trần Thị Bình", 19, "Nữ");
        _grid.ClearSelection();
    }

    private void BuildUi()
    {
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(8) };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60)); layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40)); Controls.Add(layout);
        _grid.Dock = DockStyle.Fill; _grid.ReadOnly = true; _grid.AllowUserToAddRows = false; _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; _grid.MultiSelect = false; _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        layout.Controls.Add(_grid, 0, 0);
        var right = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 8, Padding = new Padding(12) };
        right.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34)); right.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66));
        for (int i=0;i<7;i++) right.RowStyles.Add(new RowStyle(SizeType.AutoSize)); right.RowStyles.Add(new RowStyle(SizeType.Percent,100)); layout.Controls.Add(right,1,0);
        AddField(right, "Mã sinh viên", _txtId, 0); AddField(right, "Họ tên", _txtName, 1); AddField(right, "Tuổi", _txtAge, 2);
        _cboGender.DropDownStyle = ComboBoxStyle.DropDownList; _cboGender.Items.AddRange(new object[] { "Nam", "Nữ" }); AddField(right, "Giới tính", _cboGender, 3);
        _pic.Dock = DockStyle.Fill; _pic.SizeMode = PictureBoxSizeMode.Zoom; _pic.BorderStyle = BorderStyle.FixedSingle; _pic.Height = 170;
        right.Controls.Add(new Label { Text = "Avatar", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 4); right.Controls.Add(_pic, 1, 4);
        _lblAvatar.Text = "Chưa chọn ảnh"; _lblAvatar.AutoEllipsis = true; right.Controls.Add(_lblAvatar, 1, 5);
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };
        var add = new Button { Text = "Thêm", AutoSize = true }; add.Click += (_,_) => AddFromInputs();
        var update = new Button { Text = "Cập nhật", AutoSize = true }; update.Click += (_,_) => { if (_source.Current is Student s) { _source.EndEdit(); _grid.Refresh(); MessageBox.Show("Đã cập nhật sinh viên."); } else MessageBox.Show("Hãy chọn sinh viên cần cập nhật."); };
        var del = new Button { Text = "Xóa", AutoSize = true }; del.Click += (_,_) => DeleteCurrent();
        var choose = new Button { Text = "Chọn ảnh", AutoSize = true }; choose.Click += (_,_) => ChooseAvatar();
        var csv = new Button { Text = "Xuất CSV", AutoSize = true }; csv.Click += (_,_) => ExportCsv();
        buttons.Controls.AddRange(new Control[] { add, update, del, choose, csv }); right.Controls.Add(buttons, 0, 6); right.SetColumnSpan(buttons, 2);
        right.Controls.Add(new Label { Text = "Chọn một dòng để xem/sửa thông tin. Dữ liệu mẫu được tạo khi mở ứng dụng.", AutoSize = true, Dock = DockStyle.Fill },0,7); right.SetColumnSpan(right.GetControlFromPosition(0,7)!,2);
        var menu = new MenuStrip(); var file = new ToolStripMenuItem("Tệp"); var export = new ToolStripMenuItem("Xuất CSV", null, (_,_)=>ExportCsv()); var exit = new ToolStripMenuItem("Thoát", null, (_,_)=>Close()); file.DropDownItems.AddRange(new ToolStripItem[]{export,exit}); menu.Items.Add(file); MainMenuStrip=menu; Controls.Add(menu); menu.Dock=DockStyle.Top;
        _grid.ContextMenuStrip = new ContextMenuStrip(); _grid.ContextMenuStrip.Items.Add("Xóa dòng", null, (_,_)=>DeleteCurrent()); _grid.ContextMenuStrip.Items.Add("Làm mới", null, (_,_)=>_grid.Refresh());
    }
    private static void AddField(TableLayoutPanel panel, string label, Control control, int row) { panel.Controls.Add(new Label { Text=label, AutoSize=true, Anchor=AnchorStyles.Left },0,row); control.Dock=DockStyle.Top; panel.Controls.Add(control,1,row); }
    private void AddStudent(string id,string name,int age,string gender) { _students.Add(new Student { StudentId=id,FullName=name,Age=age,Gender=gender }); }
    private void AddFromInputs()
    {
        var id=_txtId.Text.Trim(); var name=_txtName.Text.Trim();
        if (id.Length==0 || name.Length==0 || !int.TryParse(_txtAge.Text,out int age) || age<1 || age>120 || _cboGender.SelectedItem is null) { MessageBox.Show("Nhập mã SV, họ tên, tuổi hợp lệ và chọn giới tính."); return; }
        if (_students.Any(s=>s.StudentId.Equals(id,StringComparison.OrdinalIgnoreCase))) { MessageBox.Show("Mã sinh viên đã tồn tại."); return; }
        var s=new Student { StudentId=id,FullName=name,Age=age,Gender=_cboGender.SelectedItem.ToString()! }; _students.Add(s); _source.Position=_students.Count-1; MessageBox.Show("Đã thêm sinh viên.");
    }
    private void DeleteCurrent() { if (_source.Current is Student s && MessageBox.Show($"Xóa sinh viên {s.FullName}?","Xác nhận",MessageBoxButtons.YesNo)==DialogResult.Yes) _students.Remove(s); }
    private void ChooseAvatar()
    {
        if (_source.Current is not Student s) { MessageBox.Show("Hãy chọn sinh viên trước."); return; }
        using var dialog=new OpenFileDialog { Title="Chọn ảnh đại diện", Filter="Ảnh (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp|Tất cả tệp (*.*)|*.*" };
        if(dialog.ShowDialog()!=DialogResult.OK)return; s.AvatarPath=dialog.FileName; LoadAvatar(); _grid.Refresh();
    }
    private void LoadAvatar()
    {
        if (_pic.Image is not null) { var old=_pic.Image; _pic.Image=null; old.Dispose(); }
        if (_source.Current is Student s && File.Exists(s.AvatarPath)) { try { using var fs=new FileStream(s.AvatarPath,FileMode.Open,FileAccess.Read,FileShare.ReadWrite); using var temp=Image.FromStream(fs); _pic.Image=new Bitmap(temp); _lblAvatar.Text=s.AvatarPath; } catch { _lblAvatar.Text="Không đọc được ảnh."; } } else _lblAvatar.Text="Chưa chọn ảnh";
    }
    private void ExportCsv()
    {
        using var dialog=new SaveFileDialog { Title="Lưu danh sách sinh viên", Filter="CSV (*.csv)|*.csv", FileName="DanhSachSinhVien.csv" }; if(dialog.ShowDialog()!=DialogResult.OK)return;
        static string Csv(string? value) { value ??=""; return "\""+value.Replace("\"","\"\"")+"\""; }
        try { using var writer=new StreamWriter(dialog.FileName,false,new UTF8Encoding(true)); writer.WriteLine("StudentId,FullName,Age,Gender,AvatarPath"); foreach(var s in _students) writer.WriteLine(string.Join(",",Csv(s.StudentId),Csv(s.FullName),s.Age.ToString(CultureInfo.InvariantCulture),Csv(s.Gender),Csv(s.AvatarPath))); MessageBox.Show("Xuất CSV thành công."); }
        catch(Exception ex) { MessageBox.Show("Không thể xuất file: "+ex.Message); }
    }
}
