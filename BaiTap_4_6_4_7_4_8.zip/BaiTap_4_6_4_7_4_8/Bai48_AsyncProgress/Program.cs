namespace Bai48_AsyncProgress;

internal static class Program { [STAThread] static void Main(){ApplicationConfiguration.Initialize();Application.Run(new FormMain());} }

public class FormMain : Form
{
    private readonly Button _loadButton=new(){Text="Nạp dữ liệu",AutoSize=true};
    private readonly ProgressBar _progress=new(){Minimum=0,Maximum=100,Dock=DockStyle.Fill};
    private readonly Label _percent=new(){Text="0%",AutoSize=true,TextAlign=ContentAlignment.MiddleCenter,Dock=DockStyle.Fill};
    private readonly DataGridView _grid=new(){Dock=DockStyle.Fill,ReadOnly=true,AllowUserToAddRows=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill};
    private readonly ToolStripStatusLabel _status=new("Sẵn sàng");
    public FormMain()
    {
        Text="Bài 4.8 - Async/Await và ProgressBar"; Width=850; Height=550; StartPosition=FormStartPosition.CenterScreen;
        var layout=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(12),ColumnCount=1,RowCount=4}; layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,28));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));Controls.Add(layout);
        _loadButton.Click+=async(_,_)=>await LoadDataAsync(); layout.Controls.Add(_loadButton,0,0);layout.Controls.Add(_progress,0,1);layout.Controls.Add(_percent,0,2);layout.Controls.Add(_grid,0,3);
        var strip=new StatusStrip();strip.Items.Add(_status);Controls.Add(strip);
    }
    private async Task<List<StudentItem>> GetStudentsAsync(IProgress<int> progress)
    {
        // Task.Run giả lập tác vụ đọc dữ liệu nặng ở tiến trình nền.
        return await Task.Run(async()=>
        {
            var result=new List<StudentItem>(); const int total=20;
            for(int i=1;i<=total;i++)
            {
                await Task.Delay(150); // Giả lập thời gian đọc từng bản ghi.
                result.Add(new StudentItem{StudentId=$"SV{i:000}",FullName=$"Sinh viên {i:00}",Age=18+i%8,Gender=i%2==0?"Nữ":"Nam"});
                progress.Report(i*100/total);
            }
            return result;
        });
    }
    private async Task LoadDataAsync()
    {
        _loadButton.Enabled=false; _progress.Value=0; _percent.Text="0%"; _status.Text="Đang nạp dữ liệu...";
        var progress=new Progress<int>(value=>{_progress.Value=Math.Clamp(value,0,100);_percent.Text=$"{value}%";_status.Text=$"Đang nạp dữ liệu: {value}%";});
        try
        {
            var students=await GetStudentsAsync(progress); _grid.DataSource=students; _status.Text=$"Nạp xong {students.Count} sinh viên."; _percent.Text="100%"; _progress.Value=100;
            MessageBox.Show("Nạp dữ liệu hoàn tất.","Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
        catch(Exception ex){_status.Text="Nạp dữ liệu thất bại.";MessageBox.Show("Có lỗi khi nạp dữ liệu: "+ex.Message,"Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);}
        finally{_loadButton.Enabled=true;}
    }
}
public class StudentItem { public string StudentId{get;set;}=""; public string FullName{get;set;}=""; public int Age{get;set;} public string Gender{get;set;}=""; }
