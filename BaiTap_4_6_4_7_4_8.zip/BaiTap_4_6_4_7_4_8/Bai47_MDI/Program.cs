using System.ComponentModel;

namespace Bai47_MDI;

internal static class Program { [STAThread] static void Main(){ ApplicationConfiguration.Initialize(); Application.Run(new FormMain()); } }

public class FormMain : Form
{
    private readonly ToolStripStatusLabel _status = new("Sẵn sàng");
    private readonly ToolStripStatusLabel _user = new("Người dùng: Admin");
    private readonly ToolStripStatusLabel _clock = new("");
    public FormMain()
    {
        Text="Bài 4.7 - Khung ứng dụng MDI"; IsMdiContainer=true; WindowState=FormWindowState.Maximized;
        var menu=new MenuStrip(); var system=new ToolStripMenuItem("Hệ thống"); system.DropDownItems.Add("Đăng xuất",null,(_,_)=>{ SetStatus("Đã đăng xuất (mô phỏng)."); }); system.DropDownItems.Add("Thoát",null,(_,_)=>Close());
        var catalog=new ToolStripMenuItem("Danh mục"); catalog.DropDownItems.Add("Quản lý Sinh viên",null,(_,_)=>OpenChild<FormStudentDemo>()); catalog.DropDownItems.Add("Quản lý Sản phẩm",null,(_,_)=>OpenChild<FormProductDemo>());
        var window=new ToolStripMenuItem("Cửa sổ"); window.DropDownItems.Add("Cascade",null,(_,_)=>LayoutMdi(MdiLayout.Cascade)); window.DropDownItems.Add("Tile Horizontal",null,(_,_)=>LayoutMdi(MdiLayout.TileHorizontal)); window.DropDownItems.Add("Tile Vertical",null,(_,_)=>LayoutMdi(MdiLayout.TileVertical)); menu.Items.AddRange(new ToolStripItem[]{system,catalog,window}); MainMenuStrip=menu; Controls.Add(menu);
        var tools=new ToolStrip(); tools.Items.Add("Sinh viên",null,(_,_)=>OpenChild<FormStudentDemo>()); tools.Items.Add("Sản phẩm",null,(_,_)=>OpenChild<FormProductDemo>()); tools.Dock=DockStyle.Top; Controls.Add(tools);
        var status=new StatusStrip(); status.Items.Add(_user); status.Items.Add(new ToolStripStatusLabel(" | ")); status.Items.Add(_status); status.Items.Add(new ToolStripStatusLabel { Spring=true }); status.Items.Add(_clock); Controls.Add(status);
        var timer=new System.Windows.Forms.Timer { Interval=1000 }; timer.Tick+=(_,_)=>_clock.Text=DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"); timer.Start();
    }
    public void SetStatus(string message) => _status.Text=message;
    private void OpenChild<T>() where T:Form,new()
    {
        foreach(Form child in MdiChildren) if(child is T) { child.Activate(); return; }
        var form=new T { MdiParent=this }; form.Show();
    }
}

public class FormStudentDemo : Form
{
    private readonly DataGridView _grid=new(); private readonly BindingList<StudentRow> _data=new();
    public FormStudentDemo()
    {
        Text="Quản lý Sinh viên"; Width=800; Height=450; _data.Add(new(){Id="SV001",Name="Nguyễn Văn An",Age=20}); _data.Add(new(){Id="SV002",Name="Trần Thị Bình",Age=19});
        _grid.Dock=DockStyle.Fill; _grid.DataSource=_data; _grid.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill; _grid.SelectionMode=DataGridViewSelectionMode.FullRowSelect; _grid.AllowUserToAddRows=false; Controls.Add(_grid);
        var context=new ContextMenuStrip(); context.Items.Add("Xóa dòng",null,(_,_)=>{ if(_grid.CurrentRow?.DataBoundItem is StudentRow row){_data.Remove(row); Notify("Đã xóa sinh viên.");} }); context.Items.Add("Làm mới dữ liệu",null,(_,_)=>{_grid.Refresh();Notify("Đã làm mới danh sách sinh viên.");}); context.Items.Add("Xem chi tiết",null,(_,_)=>{ if(_grid.CurrentRow?.DataBoundItem is StudentRow row) MessageBox.Show($"Mã: {row.Id}\nHọ tên: {row.Name}\nTuổi: {row.Age}"); }); _grid.ContextMenuStrip=context;
        var add=new Button { Text="Thêm mẫu",Dock=DockStyle.Bottom,Height=35 }; add.Click+=(_,_)=>{_data.Add(new(){Id="SV"+(_data.Count+1).ToString("000"),Name="Sinh viên mới",Age=18});Notify("Đã thêm sinh viên.");}; Controls.Add(add);
    }
    private void Notify(string message){ if(MdiParent is FormMain main) main.SetStatus(message); }
}
public class FormProductDemo : Form
{
    public FormProductDemo(){ Text="Quản lý Sản phẩm"; Width=650; Height=350; var grid=new DataGridView{Dock=DockStyle.Fill,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill}; grid.DataSource=new BindingList<ProductRow>{new(){Id="SP001",Name="Laptop Dell",Price=25000000},new(){Id="SP002",Name="Chuột không dây",Price=350000}}; Controls.Add(grid); var context=new ContextMenuStrip();context.Items.Add("Làm mới dữ liệu",null,(_,_)=>grid.Refresh());context.Items.Add("Xem chi tiết",null,(_,_)=>{if(grid.CurrentRow?.DataBoundItem is ProductRow p)MessageBox.Show($"Mã: {p.Id}\nTên: {p.Name}\nGiá: {p.Price:N0} VNĐ");});grid.ContextMenuStrip=context; }
}
public class StudentRow { public string Id{get;set;}=""; public string Name{get;set;}=""; public int Age{get;set;} }
public class ProductRow { public string Id{get;set;}=""; public string Name{get;set;}=""; public decimal Price{get;set;} }
