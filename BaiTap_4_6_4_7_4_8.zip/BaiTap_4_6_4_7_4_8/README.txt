BAI TAP C# WINDOWS FORMS - VISUAL STUDIO 2022

Thu muc gom 3 project doc lap:
1. Bai46_StudentManager: BindingSource, BindingList<Student>, DataGridView, DataBindings, chon avatar bang OpenFileDialog, xuat CSV UTF-8 bang SaveFileDialog.
2. Bai47_MDI: FormMain la MDI Parent, menu he thong/danh muc/cua so, ToolStrip, StatusStrip, khong mo trung Form con, ContextMenuStrip tren danh sach.
3. Bai48_AsyncProgress: async/await, Task.Run, Task.Delay, Progress<int>, ProgressBar, phan tram, khoa nut trong luc nap, try/catch/finally.

CACH MO:
- Giai nen thu muc.
- Mo Visual Studio 2022, chon Open a project or solution, mo file .csproj trong tung thu muc project.
- Chon framework .NET 8 (Windows). May can cai workload .NET desktop development va .NET 8 SDK.
- Bam F5 de chay. Moi project la mot ung dung rieng.

Luu y: Du lieu bai 4.6/4.7 la du lieu mau trong bo nho, chua ket noi CSDL. Bài 4.6 xuat duoc CSV ra file do nguoi dung chon.
