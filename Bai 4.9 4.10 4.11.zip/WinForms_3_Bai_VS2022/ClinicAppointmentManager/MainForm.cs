using System.ComponentModel;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace ClinicAppointmentManager;


public class Appointment
{
    public string AppointmentId { get; set; } = "";
    public string PatientName { get; set; } = "";
    public string Phone { get; set; } = "";
    public DateTime AppointmentAt { get; set; } = DateTime.Now.AddHours(1);
    public string Doctor { get; set; } = "BS. Nguyễn An";
    public string Reason { get; set; } = "";
    public string Status { get; set; } = "Chờ khám";
}


public class MainForm : Form
{
    private readonly TextBox _id = new();
    private readonly TextBox _name = new();
    private readonly TextBox _phone = new();
    private readonly DateTimePicker _date = new();
    private readonly ComboBox _doctor = new();
    private readonly TextBox _reason = new();
    private readonly ComboBox _status = new();

    private readonly BindingList<Appointment> _items = new();
    private readonly BindingSource _binding = new();
    private readonly DataGridView _grid = new();
    private readonly TextBox _search = new();
    private readonly ComboBox _filter = new();
    private readonly ErrorProvider _errors = new();
    private readonly StatusStrip _statusStrip = new();
    private readonly ToolStripStatusLabel _statusLabel = new("Sẵn sàng");


    public MainForm()
    {
        Text = "Clinic Appointment Manager";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1000, 650);
        Size = new Size(1250, 780);
        BuildUi();
        SeedData();
        RefreshList();
    }

    private void BuildUi()
    {
        var menu = new MenuStrip();
        var file = new ToolStripMenuItem("&Tệp");
        file.DropDownItems.Add("Xuất CSV...", null, (_, _) => ExportCsv());
        file.DropDownItems.Add(new ToolStripSeparator());
        file.DropDownItems.Add("Thoát", null, (_, _) => Close());
        menu.Items.Add(file);
        MainMenuStrip = menu;
        Controls.Add(menu);

        var status = new StatusStrip();
        status.Items.Add(_statusLabel);
        _statusStrip.Items.AddRange(status.Items.Cast<ToolStripItem>().ToArray());
        Controls.Add(_statusStrip);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(8) };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 410));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        Controls.Add(root);
        root.BringToFront();
        menu.BringToFront();
        _statusStrip.BringToFront();

        var form = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, AutoScroll = true, Padding = new Padding(5) };
        form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 135));
        form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.Controls.Add(form, 0, 0);

        
        AddField(form, "Mã lịch hẹn", _id);

        
        AddField(form, "Họ tên bệnh nhân", _name);

        
        AddField(form, "Số điện thoại", _phone);

        _date.Format = DateTimePickerFormat.Custom; _date.CustomFormat = "dd/MM/yyyy HH:mm"; _date.ShowUpDown = true;
        AddField(form, "Ngày giờ hẹn", _date);

        _doctor.DropDownStyle = ComboBoxStyle.DropDownList; _doctor.Items.AddRange(new object[] { "BS. Nguyễn An", "BS. Trần Bình", "BS. Lê Chi" });
        AddField(form, "Bác sĩ", _doctor);

        
        AddField(form, "Lý do khám", _reason);

        _status.DropDownStyle = ComboBoxStyle.DropDownList; _status.Items.AddRange(new object[] { "Chờ khám", "Đang khám", "Hoàn tất", "Đã hủy" });
        AddField(form, "Trạng thái", _status);

        var actions = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };
        var add = new Button { Text = "Thêm", AutoSize = true };
        var update = new Button { Text = "Cập nhật", AutoSize = true };
        var delete = new Button { Text = "Xóa", AutoSize = true };
        var clear = new Button { Text = "Làm mới", AutoSize = true };
        add.Click += (_, _) => AddItem();
        update.Click += (_, _) => UpdateItem();
        delete.Click += (_, _) => DeleteItem();
        clear.Click += (_, _) => ClearForm();
        actions.Controls.AddRange(new Control[] { add, update, delete, clear });

        form.RowCount++;
        form.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        form.Controls.Add(new Label(), 0, form.RowCount - 1);
        form.Controls.Add(actions, 1, form.RowCount - 1);

        var right = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
        right.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        right.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.Controls.Add(right, 1, 0);
        var searchPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true, Padding = new Padding(4) };
        _search.Width = 330;
        _search.PlaceholderText = "Tìm theo tên bệnh nhân hoặc số điện thoại...";
        _search.TextChanged += (_, _) => RefreshList();
        _filter.DropDownStyle = ComboBoxStyle.DropDownList;
        _filter.Items.AddRange(new object[] { "Tất cả", "Chờ khám", "Đang khám", "Hoàn tất", "Đã hủy" });
        _filter.SelectedIndex = 0;
        _filter.SelectedIndexChanged += (_, _) => RefreshList();
        searchPanel.Controls.Add(new Label { Text = "Tìm kiếm:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) });
        searchPanel.Controls.Add(_search);
        searchPanel.Controls.Add(new Label { Text = "Lọc trạng thái :", AutoSize = true, Padding = new Padding(0, 7, 0, 0) });
        searchPanel.Controls.Add(_filter);
        right.Controls.Add(searchPanel, 0, 0);

        _grid.Dock = DockStyle.Fill;
        _grid.AutoGenerateColumns = false;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect = false;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "AppointmentId", HeaderText = "Mã lịch hẹn", Name = "AppointmentId" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "PatientName", HeaderText = "Bệnh nhân", Name = "PatientName" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Phone", HeaderText = "Điện thoại", Name = "Phone" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "AppointmentAt", HeaderText = "Ngày giờ hẹn", Name = "AppointmentAt" , DefaultCellStyle = new DataGridViewCellStyle { Format = "dd/MM/yyyy HH:mm" } });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Doctor", HeaderText = "Bác sĩ", Name = "Doctor" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Reason", HeaderText = "Lý do khám", Name = "Reason" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Status", HeaderText = "Trạng thái", Name = "Status" });
        _grid.SelectionChanged += (_, _) => LoadSelected();
        right.Controls.Add(_grid, 0, 1);
        _errors.ContainerControl = this;
    }

    private void AddField(TableLayoutPanel panel, string label, Control control)
    {
        int row = panel.RowCount++;
        panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        panel.Controls.Add(new Label { Text = label + ":", AutoSize = true, Anchor = AnchorStyles.Left, Padding = new Padding(0, 6, 0, 0) }, 0, row);
        control.Dock = DockStyle.Top;
        panel.Controls.Add(control, 1, row);
    }

    private void SeedData()
    {

_items.Add(new Appointment { AppointmentId="LH001", PatientName="Nguyễn Minh Anh", Phone="0912345678", AppointmentAt=DateTime.Today.AddHours(9), Doctor="BS. Nguyễn An", Reason="Khám tổng quát", Status="Chờ khám" });
_items.Add(new Appointment { AppointmentId="LH002", PatientName="Trần Quốc Bảo", Phone="0987654321", AppointmentAt=DateTime.Today.AddHours(14), Doctor="BS. Trần Bình", Reason="Đau đầu", Status="Đang khám" });

    }

    private void Error(Control control, string message) { _errors.SetError(control, message); }
    private bool ValidateForm()
    {
        _errors.Clear();

        if (string.IsNullOrWhiteSpace(_id.Text)) Error(_id, "Nhập mã lịch hẹn.");
        if (string.IsNullOrWhiteSpace(_name.Text)) Error(_name, "Nhập họ tên bệnh nhân.");
        if (!Regex.IsMatch(_phone.Text.Trim(), @"^\+?[0-9][0-9\s.-]{7,14}$")) Error(_phone, "Số điện thoại không hợp lệ.");
        if (string.IsNullOrWhiteSpace(_reason.Text)) Error(_reason, "Nhập lý do khám.");
        if (_date.Value < DateTime.Now) Error(_date, "Ngày giờ hẹn không được ở quá khứ.");

        if (_errors.GetError(_id) != "" || _errors.GetError(_name) != "" || _errors.GetError(_phone) != "" || _errors.GetError(_reason) != "" || _errors.GetError(_date) != "")
            return false;
        return true;
    }

    private Appointment ReadForm() => new()
        {
            AppointmentId = _id.Text.Trim(),
            PatientName = _name.Text.Trim(),
            Phone = _phone.Text.Trim(),
            AppointmentAt = _date.Value,
            Doctor = Convert.ToString(_doctor.SelectedItem) ?? "",
            Reason = _reason.Text.Trim(),
            Status = Convert.ToString(_status.SelectedItem) ?? ""
        };

    private void AddItem()
    {
        if (!ValidateForm()) return;
        var item = ReadForm();
        if (_items.Any(x => x.AppointmentId.Equals(item.AppointmentId, StringComparison.OrdinalIgnoreCase)))
        { MessageBox.Show("Mã đã tồn tại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
        _items.Add(item);
        RefreshList();
        ClearForm();
    }

    private void UpdateItem()
    {
        if (_grid.CurrentRow?.DataBoundItem is not Appointment selected) { MessageBox.Show("Hãy chọn một dòng cần cập nhật."); return; }
        if (!ValidateForm()) return;
        var item = ReadForm();
        if (!selected.AppointmentId.Equals(item.AppointmentId, StringComparison.OrdinalIgnoreCase) &&
            _items.Any(x => x.AppointmentId.Equals(item.AppointmentId, StringComparison.OrdinalIgnoreCase)))
        { MessageBox.Show("Mã đã tồn tại."); return; }
        int index = _items.IndexOf(selected);
        _items[index] = item;
        RefreshList();
    }

    private void DeleteItem()
    {
        if (_grid.CurrentRow?.DataBoundItem is not Appointment selected) return;
        if (MessageBox.Show("Bạn có chắc muốn xóa bản ghi đã chọn?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        _items.Remove(selected);
        RefreshList();
        ClearForm();
    }

    private void ClearForm()
    {
_id.Clear();
        _name.Clear();
        _phone.Clear();
        _date.Value = DateTime.Now.AddHours(1);
        _doctor.SelectedIndex = 0;
        _reason.Clear();
        _status.SelectedIndex = 0;
        _errors.Clear();

    }

    private void LoadSelected()
    {
        if (_grid.CurrentRow?.DataBoundItem is not Appointment item) return;
        _id.Text = item.AppointmentId;
        _name.Text = item.PatientName;
        _phone.Text = item.Phone;
        _date.Value = item.AppointmentAt;
        _doctor.SelectedItem = item.Doctor;
        _reason.Text = item.Reason;
        _status.SelectedItem = item.Status;
    }

    private void RefreshList()
    {
        string term = _search.Text.Trim();
        var filtered = _items.Where(item =>
            (string.IsNullOrWhiteSpace(term) || item.PatientName.Contains(term, StringComparison.OrdinalIgnoreCase) || item.Phone.Contains(term, StringComparison.OrdinalIgnoreCase)) &&
            (_filter.SelectedItem?.ToString() == "Tất cả" || item.Status == _filter.SelectedItem?.ToString())).ToList();
        _binding.DataSource = new BindingList<Appointment>(filtered);
        _grid.DataSource = _binding;
        UpdateSummary(filtered.Count);
    }


    private void UpdateSummary(int count) => _statusLabel.Text = $"Số lịch hẹn sau lọc: {count}";

    private void ExportCsv()
    {
        using var dialog = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = "LichHen.csv", Title = "Xuất danh sách đang hiển thị" };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        var term = _search.Text.Trim();
        var filtered = _items.Where(item =>
            (string.IsNullOrWhiteSpace(term) || item.PatientName.Contains(term, StringComparison.OrdinalIgnoreCase) || item.Phone.Contains(term, StringComparison.OrdinalIgnoreCase)) &&
            (_filter.SelectedItem?.ToString() == "Tất cả" || item.Status == _filter.SelectedItem?.ToString())).ToList();
        static string Escape(string value) => "\"" + value.Replace("\"", "\"\"") + "\"";
        var lines = new List<string> { string.Join(",", new[] { "AppointmentId", "PatientName", "Phone", "AppointmentAt", "Doctor", "Reason", "Status" }) };
        foreach (var item in filtered)
            lines.Add(string.Join(",", new[] { item.AppointmentId, item.PatientName, item.Phone, item.AppointmentAt.ToString("yyyy-MM-dd HH:mm"), item.Doctor, item.Reason, item.Status }.Select(v => Escape(Convert.ToString(v) ?? ""))));
        File.WriteAllLines(dialog.FileName, lines, new UTF8Encoding(true));
        MessageBox.Show($"Đã xuất {filtered.Count} bản ghi.", "Hoàn tất", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
