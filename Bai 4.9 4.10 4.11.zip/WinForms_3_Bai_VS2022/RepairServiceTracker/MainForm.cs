using System.ComponentModel;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace RepairServiceTracker;


public class RepairOrder
{
    public string OrderId { get; set; } = "";
    public string CustomerName { get; set; } = "";
    public string Phone { get; set; } = "";
    public string DeviceType { get; set; } = "Laptop";
    public string FaultDescription { get; set; } = "";
    public DateTime ReceivedDate { get; set; } = DateTime.Today;
    public decimal EstimatedCost { get; set; }
    public string Status { get; set; } = "Mới tiếp nhận";
    public string ImagePath { get; set; } = "";
}


public class MainForm : Form
{
    private readonly TextBox _id = new();
    private readonly TextBox _name = new();
    private readonly TextBox _phone = new();
    private readonly ComboBox _device = new();
    private readonly TextBox _description = new();
    private readonly DateTimePicker _date = new();
    private readonly NumericUpDown _cost = new() { Minimum = 0, Maximum = 1000000000, DecimalPlaces = 0, ThousandsSeparator = true, Increment = 10000 };
    private readonly ComboBox _status = new();
    private readonly TextBox _image = new() { ReadOnly = true };

    private readonly BindingList<RepairOrder> _items = new();
    private readonly BindingSource _binding = new();
    private readonly DataGridView _grid = new();
    private readonly TextBox _search = new();
    private readonly ComboBox _filter = new();
    private readonly ErrorProvider _errors = new();
    private readonly StatusStrip _statusStrip = new();
    private readonly ToolStripStatusLabel _statusLabel = new("Sẵn sàng");

    private readonly PictureBox _picture = new() { Dock = DockStyle.Fill, SizeMode = PictureBoxSizeMode.Zoom, BorderStyle = BorderStyle.FixedSingle };

    public MainForm()
    {
        Text = "Repair Service Tracker";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1000, 650);
        Size = new Size(1250, 780);
        BuildUi();
        SeedData();
        RefreshList();
    }

    private void BuildUi()
    {
        var menu = new MenuStrip();
        var file = new ToolStripMenuItem("&Tệp");
        file.DropDownItems.Add("Xuất CSV...", null, (_, _) => ExportCsv());
        file.DropDownItems.Add(new ToolStripSeparator());
        file.DropDownItems.Add("Thoát", null, (_, _) => Close());
        menu.Items.Add(file);
        MainMenuStrip = menu;
        Controls.Add(menu);

        var status = new StatusStrip();
        status.Items.Add(_statusLabel);
        _statusStrip.Items.AddRange(status.Items.Cast<ToolStripItem>().ToArray());
        Controls.Add(_statusStrip);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(8) };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 410));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        Controls.Add(root);
        root.BringToFront();
        menu.BringToFront();
        _statusStrip.BringToFront();

        var form = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, AutoScroll = true, Padding = new Padding(5) };
        form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 135));
        form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.Controls.Add(form, 0, 0);

        
        AddField(form, "Mã đơn", _id);

        
        AddField(form, "Tên khách hàng", _name);

        
        AddField(form, "Số điện thoại", _phone);

        _device.DropDownStyle = ComboBoxStyle.DropDownList; _device.Items.AddRange(new object[] { "Laptop", "Điện thoại", "Máy tính bảng", "Máy tính để bàn", "Thiết bị khác" });
        AddField(form, "Loại thiết bị", _device);

        
        AddField(form, "Mô tả lỗi", _description);

        _date.Format = DateTimePickerFormat.Custom; _date.CustomFormat = "dd/MM/yyyy";
        AddField(form, "Ngày tiếp nhận", _date);

        
        AddField(form, "Chi phí dự kiến", _cost);

        _status.DropDownStyle = ComboBoxStyle.DropDownList; _status.Items.AddRange(new object[] { "Mới tiếp nhận", "Đang sửa", "Chờ linh kiện", "Hoàn tất", "Đã hủy" });
        AddField(form, "Trạng thái", _status);

        AddField(form, "Ảnh thiết bị", _image);
        var chooseImage = new Button { Text = "Chọn ảnh..." };
        chooseImage.Click += (_, _) => ChooseImage();
        var imageRow = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true };
        imageRow.Controls.Add(_image); imageRow.Controls.Add(chooseImage);
        form.Controls.Remove(_image); // replaced by image row in this row
        form.Controls.Add(imageRow, 1, form.RowCount - 1);

        var picturePanel = new Panel { Dock = DockStyle.Fill, Height = 150 };
        picturePanel.Controls.Add(_picture);
        AddField(form, "Xem ảnh", picturePanel);

        var actions = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };
        var add = new Button { Text = "Thêm", AutoSize = true };
        var update = new Button { Text = "Cập nhật", AutoSize = true };
        var delete = new Button { Text = "Xóa", AutoSize = true };
        var clear = new Button { Text = "Làm mới", AutoSize = true };
        add.Click += (_, _) => AddItem();
        update.Click += (_, _) => UpdateItem();
        delete.Click += (_, _) => DeleteItem();
        clear.Click += (_, _) => ClearForm();
        actions.Controls.AddRange(new Control[] { add, update, delete, clear });

        form.RowCount++;
        form.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        form.Controls.Add(new Label(), 0, form.RowCount - 1);
        form.Controls.Add(actions, 1, form.RowCount - 1);

        var right = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
        right.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        right.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.Controls.Add(right, 1, 0);
        var searchPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true, Padding = new Padding(4) };
        _search.Width = 330;
        _search.PlaceholderText = "Tìm theo mã đơn, tên khách hoặc số điện thoại...";
        _search.TextChanged += (_, _) => RefreshList();
        _filter.DropDownStyle = ComboBoxStyle.DropDownList;
        _filter.Items.AddRange(new object[] { "Tất cả", "Mới tiếp nhận", "Đang sửa", "Chờ linh kiện", "Hoàn tất", "Đã hủy" });
        _filter.SelectedIndex = 0;
        _filter.SelectedIndexChanged += (_, _) => RefreshList();
        searchPanel.Controls.Add(new Label { Text = "Tìm kiếm:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) });
        searchPanel.Controls.Add(_search);
        searchPanel.Controls.Add(new Label { Text = "Lọc trạng thái :", AutoSize = true, Padding = new Padding(0, 7, 0, 0) });
        searchPanel.Controls.Add(_filter);
        right.Controls.Add(searchPanel, 0, 0);

        _grid.Dock = DockStyle.Fill;
        _grid.AutoGenerateColumns = false;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect = false;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "OrderId", HeaderText = "Mã đơn", Name = "OrderId" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "CustomerName", HeaderText = "Khách hàng", Name = "CustomerName" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Phone", HeaderText = "Điện thoại", Name = "Phone" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "DeviceType", HeaderText = "Thiết bị", Name = "DeviceType" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "FaultDescription", HeaderText = "Mô tả lỗi", Name = "FaultDescription" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "ReceivedDate", HeaderText = "Ngày tiếp nhận", Name = "ReceivedDate" , DefaultCellStyle = new DataGridViewCellStyle { Format = "dd/MM/yyyy" } });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "EstimatedCost", HeaderText = "Chi phí dự kiến", Name = "EstimatedCost" , DefaultCellStyle = new DataGridViewCellStyle { Format = "N0" } });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Status", HeaderText = "Trạng thái", Name = "Status" });
        _grid.SelectionChanged += (_, _) => LoadSelected();
        right.Controls.Add(_grid, 0, 1);
        _errors.ContainerControl = this;
    }

    private void AddField(TableLayoutPanel panel, string label, Control control)
    {
        int row = panel.RowCount++;
        panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        panel.Controls.Add(new Label { Text = label + ":", AutoSize = true, Anchor = AnchorStyles.Left, Padding = new Padding(0, 6, 0, 0) }, 0, row);
        control.Dock = DockStyle.Top;
        panel.Controls.Add(control, 1, row);
    }

    private void SeedData()
    {

_items.Add(new RepairOrder { OrderId="SC001", CustomerName="Đỗ Gia Huy", Phone="0901122334", DeviceType="Laptop", FaultDescription="Máy không khởi động", ReceivedDate=DateTime.Today.AddDays(-1), EstimatedCost=850000, Status="Mới tiếp nhận" });
_items.Add(new RepairOrder { OrderId="SC002", CustomerName="Vũ Thanh Mai", Phone="0933445566", DeviceType="Điện thoại", FaultDescription="Thay màn hình", ReceivedDate=DateTime.Today, EstimatedCost=1200000, Status="Đang sửa" });

    }

    private void Error(Control control, string message) { _errors.SetError(control, message); }
    private bool ValidateForm()
    {
        _errors.Clear();

        if (string.IsNullOrWhiteSpace(_id.Text)) Error(_id, "Nhập mã đơn.");
        if (string.IsNullOrWhiteSpace(_name.Text)) Error(_name, "Nhập tên khách hàng.");
        if (!Regex.IsMatch(_phone.Text.Trim(), @"^\+?[0-9][0-9\s.-]{7,14}$")) Error(_phone, "Số điện thoại không hợp lệ.");
        if (string.IsNullOrWhiteSpace(_description.Text)) Error(_description, "Nhập mô tả lỗi.");
        if (_cost.Value < 0) Error(_cost, "Chi phí không được âm.");

        if (_errors.GetError(_id) != "" || _errors.GetError(_name) != "" || _errors.GetError(_phone) != "" || _errors.GetError(_description) != "" || _errors.GetError(_cost) != "")
            return false;
        return true;
    }

    private RepairOrder ReadForm() => new()
        {
            OrderId = _id.Text.Trim(),
            CustomerName = _name.Text.Trim(),
            Phone = _phone.Text.Trim(),
            DeviceType = Convert.ToString(_device.SelectedItem) ?? "",
            FaultDescription = _description.Text.Trim(),
            ReceivedDate = _date.Value,
            EstimatedCost = _cost.Value,
            Status = Convert.ToString(_status.SelectedItem) ?? "",
            ImagePath = _image.Text
        };

    private void AddItem()
    {
        if (!ValidateForm()) return;
        var item = ReadForm();
        if (_items.Any(x => x.OrderId.Equals(item.OrderId, StringComparison.OrdinalIgnoreCase)))
        { MessageBox.Show("Mã đã tồn tại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
        _items.Add(item);
        RefreshList();
        ClearForm();
    }

    private void UpdateItem()
    {
        if (_grid.CurrentRow?.DataBoundItem is not RepairOrder selected) { MessageBox.Show("Hãy chọn một dòng cần cập nhật."); return; }
        if (!ValidateForm()) return;
        var item = ReadForm();
        if (!selected.OrderId.Equals(item.OrderId, StringComparison.OrdinalIgnoreCase) &&
            _items.Any(x => x.OrderId.Equals(item.OrderId, StringComparison.OrdinalIgnoreCase)))
        { MessageBox.Show("Mã đã tồn tại."); return; }
        int index = _items.IndexOf(selected);
        _items[index] = item;
        RefreshList();
    }

    private void DeleteItem()
    {
        if (_grid.CurrentRow?.DataBoundItem is not RepairOrder selected) return;
        if (MessageBox.Show("Bạn có chắc muốn xóa bản ghi đã chọn?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        _items.Remove(selected);
        RefreshList();
        ClearForm();
    }

    private void ClearForm()
    {
_id.Clear();
        _name.Clear();
        _phone.Clear();
        _device.SelectedIndex = 0;
        _description.Clear();
        _date.Value = DateTime.Today;
        _cost.Value = 0;
        _status.SelectedIndex = 0;
        _image.Clear();
        _errors.Clear();
        _picture.Image = null;

    }

    private void LoadSelected()
    {
        if (_grid.CurrentRow?.DataBoundItem is not RepairOrder item) return;
        _id.Text = item.OrderId;
        _name.Text = item.CustomerName;
        _phone.Text = item.Phone;
        _device.SelectedItem = item.DeviceType;
        _description.Text = item.FaultDescription;
        _date.Value = item.ReceivedDate;
        _cost.Value = Math.Clamp(item.EstimatedCost, _cost.Minimum, _cost.Maximum);
        _status.SelectedItem = item.Status;
        _image.Text = item.ImagePath; try { _picture.Image = File.Exists(item.ImagePath) ? Image.FromFile(item.ImagePath) : null; } catch { _picture.Image = null; }
    }

    private void RefreshList()
    {
        string term = _search.Text.Trim();
        var filtered = _items.Where(item =>
            (string.IsNullOrWhiteSpace(term) || item.OrderId.Contains(term, StringComparison.OrdinalIgnoreCase) || item.CustomerName.Contains(term, StringComparison.OrdinalIgnoreCase) || item.Phone.Contains(term, StringComparison.OrdinalIgnoreCase)) &&
            (_filter.SelectedItem?.ToString() == "Tất cả" || item.Status == _filter.SelectedItem?.ToString())).ToList();
        _binding.DataSource = new BindingList<RepairOrder>(filtered);
        _grid.DataSource = _binding;
        UpdateSummary(filtered.Count);
    }


    private void UpdateSummary(int count)
    {
        decimal total = _items.Where(x => x.Status != "Hoàn tất" && x.Status != "Đã hủy").Sum(x => x.EstimatedCost);
        _statusLabel.Text = $"Số đơn sau lọc: {count} | Chi phí đơn chưa hoàn tất: {total:N0} VNĐ";
    }

    private void ChooseImage()
    {
        using var dialog = new OpenFileDialog { Filter = "Tệp ảnh|*.jpg;*.jpeg;*.png;*.bmp;*.gif", Title = "Chọn ảnh thiết bị" };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        _image.Text = dialog.FileName;
        try { _picture.Image = Image.FromFile(dialog.FileName); } catch { _picture.Image = null; }
    }

    private void ExportCsv()
    {
        using var dialog = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = "DonSuaChua.csv", Title = "Xuất danh sách đang hiển thị" };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        var term = _search.Text.Trim();
        var filtered = _items.Where(item =>
            (string.IsNullOrWhiteSpace(term) || item.OrderId.Contains(term, StringComparison.OrdinalIgnoreCase) || item.CustomerName.Contains(term, StringComparison.OrdinalIgnoreCase) || item.Phone.Contains(term, StringComparison.OrdinalIgnoreCase)) &&
            (_filter.SelectedItem?.ToString() == "Tất cả" || item.Status == _filter.SelectedItem?.ToString())).ToList();
        static string Escape(string value) => "\"" + value.Replace("\"", "\"\"") + "\"";
        var lines = new List<string> { string.Join(",", new[] { "OrderId", "CustomerName", "Phone", "DeviceType", "FaultDescription", "ReceivedDate", "EstimatedCost", "Status" }) };
        foreach (var item in filtered)
            lines.Add(string.Join(",", new[] { item.OrderId, item.CustomerName, item.Phone, item.DeviceType, item.FaultDescription, item.ReceivedDate.ToString("yyyy-MM-dd"), item.EstimatedCost.ToString("N0", CultureInfo.InvariantCulture), item.Status }.Select(v => Escape(Convert.ToString(v) ?? ""))));
        File.WriteAllLines(dialog.FileName, lines, new UTF8Encoding(true));
        MessageBox.Show($"Đã xuất {filtered.Count} bản ghi.", "Hoàn tất", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
