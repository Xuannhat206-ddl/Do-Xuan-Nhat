using System.ComponentModel;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace LabEquipmentCheckout;


public class Checkout
{
    public string TicketId { get; set; } = "";
    public string StudentId { get; set; } = "";
    public string StudentName { get; set; } = "";
    public string Equipment { get; set; } = "Laptop";
    public int Quantity { get; set; } = 1;
    public DateTime BorrowDate { get; set; } = DateTime.Today;
    public DateTime DueDate { get; set; } = DateTime.Today.AddDays(7);
    public DateTime? ActualReturnDate { get; set; }
    public string Status { get; set; } = "Đang mượn";
}


public class MainForm : Form
{
    private readonly TextBox _id = new();
    private readonly TextBox _studentid = new();
    private readonly TextBox _name = new();
    private readonly ComboBox _equipment = new();
    private readonly NumericUpDown _quantity = new() { Minimum = 1, Maximum = 10000, Value = 1 };
    private readonly DateTimePicker _borrow = new();
    private readonly DateTimePicker _due = new();
    private readonly DateTimePicker _returned = new();
    private readonly ComboBox _status = new();

    private readonly BindingList<Checkout> _items = new();
    private readonly BindingSource _binding = new();
    private readonly DataGridView _grid = new();
    private readonly TextBox _search = new();
    private readonly ComboBox _filter = new();
    private readonly ErrorProvider _errors = new();
    private readonly StatusStrip _statusStrip = new();
    private readonly ToolStripStatusLabel _statusLabel = new("Sẵn sàng");


    public MainForm()
    {
        Text = "Lab Equipment Checkout";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1000, 650);
        Size = new Size(1250, 780);
        BuildUi();
        SeedData();
        RefreshList();
    }

    private void BuildUi()
    {
        var menu = new MenuStrip();
        var file = new ToolStripMenuItem("&Tệp");
        file.DropDownItems.Add("Xuất CSV...", null, (_, _) => ExportCsv());
        file.DropDownItems.Add(new ToolStripSeparator());
        file.DropDownItems.Add("Thoát", null, (_, _) => Close());
        menu.Items.Add(file);
        MainMenuStrip = menu;
        Controls.Add(menu);

        var status = new StatusStrip();
        status.Items.Add(_statusLabel);
        _statusStrip.Items.AddRange(status.Items.Cast<ToolStripItem>().ToArray());
        Controls.Add(_statusStrip);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(8) };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 410));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        Controls.Add(root);
        root.BringToFront();
        menu.BringToFront();
        _statusStrip.BringToFront();

        var form = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, AutoScroll = true, Padding = new Padding(5) };
        form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 135));
        form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.Controls.Add(form, 0, 0);

        
        AddField(form, "Mã phiếu", _id);

        
        AddField(form, "Mã sinh viên", _studentid);

        
        AddField(form, "Họ tên sinh viên", _name);

        _equipment.DropDownStyle = ComboBoxStyle.DropDownList; _equipment.Items.AddRange(new object[] { "Laptop", "Máy chiếu", "Máy tính", "Màn hình", "Bàn phím", "Chuột" });
        AddField(form, "Thiết bị", _equipment);

        
        AddField(form, "Số lượng", _quantity);

        _borrow.Format = DateTimePickerFormat.Custom; _borrow.CustomFormat = "dd/MM/yyyy";
        AddField(form, "Ngày mượn", _borrow);

        _due.Format = DateTimePickerFormat.Custom; _due.CustomFormat = "dd/MM/yyyy";
        AddField(form, "Hạn trả", _due);

        _returned.Format = DateTimePickerFormat.Custom; _returned.CustomFormat = "dd/MM/yyyy"; _returned.ShowCheckBox = true; _returned.Checked = false;
        AddField(form, "Ngày trả thực tế", _returned);

        _status.DropDownStyle = ComboBoxStyle.DropDownList; _status.Items.AddRange(new object[] { "Đang mượn", "Đã trả", "Quá hạn" });
        AddField(form, "Tình trạng", _status);

        var actions = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };
        var add = new Button { Text = "Thêm", AutoSize = true };
        var update = new Button { Text = "Cập nhật", AutoSize = true };
        var delete = new Button { Text = "Xóa", AutoSize = true };
        var clear = new Button { Text = "Làm mới", AutoSize = true };
        add.Click += (_, _) => AddItem();
        update.Click += (_, _) => UpdateItem();
        delete.Click += (_, _) => DeleteItem();
        clear.Click += (_, _) => ClearForm();
        actions.Controls.AddRange(new Control[] { add, update, delete, clear });

        var returnButton = new Button { Text = "Đánh dấu đã trả", AutoSize = true };
        returnButton.Click += (_, _) => MarkReturned();
        actions.Controls.Add(returnButton);

        form.RowCount++;
        form.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        form.Controls.Add(new Label(), 0, form.RowCount - 1);
        form.Controls.Add(actions, 1, form.RowCount - 1);

        var right = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
        right.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        right.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.Controls.Add(right, 1, 0);
        var searchPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true, Padding = new Padding(4) };
        _search.Width = 330;
        _search.PlaceholderText = "Tìm theo mã sinh viên hoặc tên thiết bị...";
        _search.TextChanged += (_, _) => RefreshList();
        _filter.DropDownStyle = ComboBoxStyle.DropDownList;
        _filter.Items.AddRange(new object[] { "Tất cả", "Đang mượn", "Quá hạn", "Đã trả" });
        _filter.SelectedIndex = 0;
        _filter.SelectedIndexChanged += (_, _) => RefreshList();
        searchPanel.Controls.Add(new Label { Text = "Tìm kiếm:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) });
        searchPanel.Controls.Add(_search);
        searchPanel.Controls.Add(new Label { Text = "Lọc tình trạng :", AutoSize = true, Padding = new Padding(0, 7, 0, 0) });
        searchPanel.Controls.Add(_filter);
        right.Controls.Add(searchPanel, 0, 0);

        _grid.Dock = DockStyle.Fill;
        _grid.AutoGenerateColumns = false;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect = false;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "TicketId", HeaderText = "Mã phiếu", Name = "TicketId" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "StudentId", HeaderText = "Mã sinh viên", Name = "StudentId" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "StudentName", HeaderText = "Sinh viên", Name = "StudentName" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Equipment", HeaderText = "Thiết bị", Name = "Equipment" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Quantity", HeaderText = "Số lượng", Name = "Quantity" });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "BorrowDate", HeaderText = "Ngày mượn", Name = "BorrowDate" , DefaultCellStyle = new DataGridViewCellStyle { Format = "dd/MM/yyyy" } });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "DueDate", HeaderText = "Hạn trả", Name = "DueDate" , DefaultCellStyle = new DataGridViewCellStyle { Format = "dd/MM/yyyy" } });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "ActualReturnDate", HeaderText = "Ngày trả thực tế", Name = "ActualReturnDate" , DefaultCellStyle = new DataGridViewCellStyle { Format = "dd/MM/yyyy" } });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Status", HeaderText = "Tình trạng", Name = "Status" });
        _grid.SelectionChanged += (_, _) => LoadSelected();
        right.Controls.Add(_grid, 0, 1);
        _errors.ContainerControl = this;
    }

    private void AddField(TableLayoutPanel panel, string label, Control control)
    {
        int row = panel.RowCount++;
        panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        panel.Controls.Add(new Label { Text = label + ":", AutoSize = true, Anchor = AnchorStyles.Left, Padding = new Padding(0, 6, 0, 0) }, 0, row);
        control.Dock = DockStyle.Top;
        panel.Controls.Add(control, 1, row);
    }

    private void SeedData()
    {

_items.Add(new Checkout { TicketId="PM001", StudentId="SV001", StudentName="Lê Hoàng Nam", Equipment="Laptop", Quantity=1, BorrowDate=DateTime.Today.AddDays(-3), DueDate=DateTime.Today.AddDays(4), Status="Đang mượn" });
_items.Add(new Checkout { TicketId="PM002", StudentId="SV002", StudentName="Phạm Thu Hà", Equipment="Máy chiếu", Quantity=1, BorrowDate=DateTime.Today.AddDays(-10), DueDate=DateTime.Today.AddDays(-2), Status="Đang mượn" });

    }

    private void Error(Control control, string message) { _errors.SetError(control, message); }
    private bool ValidateForm()
    {
        _errors.Clear();

        if (string.IsNullOrWhiteSpace(_id.Text)) Error(_id, "Nhập mã phiếu.");
        if (string.IsNullOrWhiteSpace(_studentid.Text)) Error(_studentid, "Nhập mã sinh viên.");
        if (string.IsNullOrWhiteSpace(_name.Text)) Error(_name, "Nhập họ tên sinh viên.");
        if (_due.Value.Date < _borrow.Value.Date) Error(_due, "Hạn trả không được trước ngày mượn.");
        if (_returned.Checked && _returned.Value.Date < _borrow.Value.Date) Error(_returned, "Ngày trả không được trước ngày mượn.");

        if (_errors.GetError(_id) != "" || _errors.GetError(_studentid) != "" || _errors.GetError(_name) != "" || _errors.GetError(_due) != "" || _errors.GetError(_returned) != "")
            return false;
        return true;
    }

    private Checkout ReadForm() => new()
        {
            TicketId = _id.Text.Trim(),
            StudentId = _studentid.Text.Trim(),
            StudentName = _name.Text.Trim(),
            Equipment = Convert.ToString(_equipment.SelectedItem) ?? "",
            Quantity = (int)_quantity.Value,
            BorrowDate = _borrow.Value,
            DueDate = _due.Value,
            ActualReturnDate = _returned.Checked ? _returned.Value.Date : null,
            Status = Convert.ToString(_status.SelectedItem) ?? ""
        };

    private void AddItem()
    {
        if (!ValidateForm()) return;
        var item = ReadForm();
        if (_items.Any(x => x.TicketId.Equals(item.TicketId, StringComparison.OrdinalIgnoreCase)))
        { MessageBox.Show("Mã đã tồn tại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
        _items.Add(item);
        RefreshList();
        ClearForm();
    }

    private void UpdateItem()
    {
        if (_grid.CurrentRow?.DataBoundItem is not Checkout selected) { MessageBox.Show("Hãy chọn một dòng cần cập nhật."); return; }
        if (!ValidateForm()) return;
        var item = ReadForm();
        if (!selected.TicketId.Equals(item.TicketId, StringComparison.OrdinalIgnoreCase) &&
            _items.Any(x => x.TicketId.Equals(item.TicketId, StringComparison.OrdinalIgnoreCase)))
        { MessageBox.Show("Mã đã tồn tại."); return; }
        int index = _items.IndexOf(selected);
        _items[index] = item;
        RefreshList();
    }

    private void DeleteItem()
    {
        if (_grid.CurrentRow?.DataBoundItem is not Checkout selected) return;
        if (MessageBox.Show("Bạn có chắc muốn xóa bản ghi đã chọn?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        _items.Remove(selected);
        RefreshList();
        ClearForm();
    }

    private void ClearForm()
    {
_id.Clear();
        _studentid.Clear();
        _name.Clear();
        _equipment.SelectedIndex = 0;
        _quantity.Value = 1;
        _borrow.Value = DateTime.Today;
        _due.Value = DateTime.Today;
        _returned.Checked = false;
        _status.SelectedIndex = 0;
        _errors.Clear();

    }

    private void LoadSelected()
    {
        if (_grid.CurrentRow?.DataBoundItem is not Checkout item) return;
        _id.Text = item.TicketId;
        _studentid.Text = item.StudentId;
        _name.Text = item.StudentName;
        _equipment.SelectedItem = item.Equipment;
        _quantity.Value = Math.Clamp(item.Quantity, (int)_quantity.Minimum, (int)_quantity.Maximum);
        _borrow.Value = item.BorrowDate;
        _due.Value = item.DueDate;
        _returned.Checked = item.ActualReturnDate.HasValue; if (item.ActualReturnDate.HasValue) _returned.Value = item.ActualReturnDate.Value;
        _status.SelectedItem = item.Status;
    }

    private void RefreshList()
    {
        // Đồng bộ trạng thái hiển thị dựa trên hạn trả hiện tại.
        foreach (var item in _items)
            if (item.Status != "Đã trả")
                item.Status = item.DueDate.Date < DateTime.Today ? "Quá hạn" : "Đang mượn";
        string term = _search.Text.Trim();
        var filtered = _items.Where(item =>
            (string.IsNullOrWhiteSpace(term) || item.StudentId.Contains(term, StringComparison.OrdinalIgnoreCase) || item.Equipment.Contains(term, StringComparison.OrdinalIgnoreCase)) &&
            (_filter.SelectedItem?.ToString() == "Tất cả" || EffectiveStatus(item) == _filter.SelectedItem?.ToString())).ToList();
        _binding.DataSource = new BindingList<Checkout>(filtered);
        _grid.DataSource = _binding;
        UpdateSummary(filtered.Count);
    }


    private static string EffectiveStatus(Checkout item)
    {
        if (item.Status == "Đã trả") return "Đã trả";
        return item.DueDate.Date < DateTime.Today ? "Quá hạn" : "Đang mượn";
    }
    private void UpdateSummary(int count)
    {
        int overdue = _items.Count(x => EffectiveStatus(x) == "Quá hạn");
        _statusLabel.Text = $"Tổng phiếu: {_items.Count} | Sau lọc: {count} | Quá hạn: {overdue}";
    }

    private void MarkReturned()
    {
        if (_grid.CurrentRow?.DataBoundItem is not Checkout selected) return;
        selected.Status = "Đã trả";
        selected.ActualReturnDate = DateTime.Today;
        RefreshList();
        LoadSelected();
    }

    private void ExportCsv()
    {
        using var dialog = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = "PhieuMuonTra.csv", Title = "Xuất danh sách đang hiển thị" };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        var term = _search.Text.Trim();
        var filtered = _items.Where(item =>
            (string.IsNullOrWhiteSpace(term) || item.StudentId.Contains(term, StringComparison.OrdinalIgnoreCase) || item.Equipment.Contains(term, StringComparison.OrdinalIgnoreCase)) &&
            (_filter.SelectedItem?.ToString() == "Tất cả" || EffectiveStatus(item) == _filter.SelectedItem?.ToString())).ToList();
        static string Escape(string value) => "\"" + value.Replace("\"", "\"\"") + "\"";
        var lines = new List<string> { string.Join(",", new[] { "TicketId", "StudentId", "StudentName", "Equipment", "Quantity", "BorrowDate", "DueDate", "ActualReturnDate", "Status" }) };
        foreach (var item in filtered)
            lines.Add(string.Join(",", new[] { item.TicketId, item.StudentId, item.StudentName, item.Equipment, item.Quantity.ToString(), item.BorrowDate.ToString("yyyy-MM-dd"), item.DueDate.ToString("yyyy-MM-dd"), item.ActualReturnDate?.ToString("yyyy-MM-dd") ?? "", EffectiveStatus(item) }.Select(v => Escape(Convert.ToString(v) ?? ""))));
        File.WriteAllLines(dialog.FileName, lines, new UTF8Encoding(true));
        MessageBox.Show($"Đã xuất {filtered.Count} bản ghi.", "Hoàn tất", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
